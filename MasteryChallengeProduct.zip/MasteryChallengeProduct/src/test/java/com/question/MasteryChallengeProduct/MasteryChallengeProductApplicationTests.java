package com.question.MasteryChallengeProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MasteryChallengeProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
